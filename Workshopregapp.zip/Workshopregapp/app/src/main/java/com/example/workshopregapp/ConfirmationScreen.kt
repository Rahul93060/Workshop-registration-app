package com.example.workshopregapp


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// ✅ Activity class (this name matters)
class ConfirmationActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = intent.getStringExtra("title") ?: ""
        val id = intent.getStringExtra("id") ?: ""
        val sessions = intent.getIntExtra("sessions", 0)

        setContent {
            MaterialTheme {
                ConfirmationScreen(title, id, sessions)
            }
        }
    }
}

// ✅ Composable UI
@Composable
fun ConfirmationScreen(
    title: String,
    id: String,
    sessions: Int
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Text(
            text = "Registration Confirmed ✅",
            style = MaterialTheme.typography.headlineSmall
        )

        Text(text = "Workshop Title: $title")
        Text(text = "Workshop ID: $id")
        Text(text = "Number of Sessions: $sessions")
    }
}
