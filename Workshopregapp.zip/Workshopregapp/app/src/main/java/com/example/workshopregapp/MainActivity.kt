package com.example.workshopregapp


import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                RegistrationScreen()
            }
        }
    }
}

@Composable
fun RegistrationScreen() {

    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var workshopId by remember { mutableStateOf("") }
    var sessions by remember { mutableStateOf("") }
    var isChecked by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Text(
            text = "Workshop Registration",
            style = MaterialTheme.typography.headlineSmall
        )

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Workshop Title") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = workshopId,
            onValueChange = { workshopId = it },
            label = { Text("Workshop ID") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = sessions,
            onValueChange = { sessions = it },
            label = { Text("Number of Sessions") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = isChecked,
                onCheckedChange = { isChecked = it }
            )
            Text(text = "Confirm registration details")
        }

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val sessionCount = sessions.toIntOrNull() ?: 0

                if (sessionCount > 0 && isChecked) {
                    val intent =
                        Intent(context, ConfirmationActivity::class.java)
                    intent.putExtra("title", title)
                    intent.putExtra("id", workshopId)
                    intent.putExtra("sessions", sessionCount)
                    context.startActivity(intent)
                } else {
                    errorMsg =
                        "Please enter valid details and confirm the registration."
                }
            }
        ) {
            Text("Register")
        }

        if (errorMsg.isNotEmpty()) {
            Text(
                text = errorMsg,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}
